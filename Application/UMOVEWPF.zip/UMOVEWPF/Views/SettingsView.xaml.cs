using System.Windows.Controls;

namespace UMOVEWPF.Views
{
    public partial class SettingsView : UserControl
    {
        public SettingsView()
        {
            InitializeComponent();
        }
    }
} 